# Sparkify Songplay Data Modeling

The objective of this project is to create a database from the sparkify using log data and song data files stored in JSON format. They need to be able to run ad hoc queries in order to analyse the data and determine what songs people are listening to. This analysis will he

## Data
### Song Data
Here is what the song data looks like in JSON format
"""{
"num_songs": 1,
"artist_id": "ARJIE2Y1187B994AB7",
"artist_latitude": null,
"artist_longitude": null,
"artist_location": "",
"artist_name": "Line Renaud",
"song_id": "SOUPIRU12A6D4FA1E1",
"title": "Der Kleine Dompfaff",
"duration": 152.92036,
"year": 0
}"""

### Log Data
Here is what the log data looks like in JSON format
"""{
  "artist": "Survivor",
  "auth": "Logged In",
  "firstName": "Jayden",
  "gender": "M",
  "itemInSession": 0,
  "lastName": "Fox",
  "length": 245.36771,
  "level": "free",
  "location": "New Orleans-Metairie, LA",
  "method": "PUT",
  "page": "NextSong",
  "registration": 1541033612796,
  "sessionId": 100,
  "song": "Eye Of The Tiger",
  "status": 200,
  "ts": 1541110994796,
  "userAgent": "\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36\"",
  "userId": "101"
}"""

## Schema

In order to optimize queries we created a relational database with a star schema. This was done for a few reasons:
1. The database needed to be easy to query for ad hoc analysis requests making a relational database a better choice
2. There isnt enough data to warrant using a distributed database
3. Joins will be needed for queries

There is one fact table (songplays) and four dimension table (users, time, artists, songs). 

![Songplay Database Schema](https://ibb.co/g6Rr7xd)

## ETL Pipeline


create_tables.py: This script drops the tables if they exist and then creates the tables using the queries in sql_queries.py.

etl.py: This script convertes the data from a JSON file format to a dataframe in order to transform the data. Then inserts the data into tables using the insert statements in the sql_queries.py script.

sql_queries.py: This script contains all the queries needed to create the tables and insert the data. 

test.ipynb: This script contains queries that test the different tables.

## Steps to Run

1. Run """python Create_tables.py""" in the terminal
2. Run """python etl.py"""
3. Test to make sure the data was inserted properluy using test.pynb





