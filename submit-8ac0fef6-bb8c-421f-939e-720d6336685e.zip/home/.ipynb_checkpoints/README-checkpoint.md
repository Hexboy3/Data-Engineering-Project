# Sparkify Songplay Data Modeling

The goal of this project is to create a database, so that sparkify can analyse the their user data. Before the creation of this database the data was stored in JSON files making it difficult to query and analyse the data. This database will allow sparkify query and analyse the data in order to determine which songs users are listening too.

## Data
### Song Data
Here is what the song data looks like in JSON format
"""{
"num_songs": 1,
"artist_id": "ARJIE2Y1187B994AB7",
"artist_latitude": null,
"artist_longitude": null,
"artist_location": "",
"artist_name": "Line Renaud",
"song_id": "SOUPIRU12A6D4FA1E1",
"title": "Der Kleine Dompfaff",
"duration": 152.92036,
"year": 0
}"""

### Log Data
Here is what the log data looks like in JSON format
"""{
  "artist": "Survivor",
  "auth": "Logged In",
  "firstName": "Jayden",
  "gender": "M",
  "itemInSession": 0,
  "lastName": "Fox",
  "length": 245.36771,
  "level": "free",
  "location": "New Orleans-Metairie, LA",
  "method": "PUT",
  "page": "NextSong",
  "registration": 1541033612796,
  "sessionId": 100,
  "song": "Eye Of The Tiger",
  "status": 200,
  "ts": 1541110994796,
  "userAgent": "\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36\"",
  "userId": "101"
}"""

## Schema

### Fact Table

![Schema](https://ibb.co/g6Rr7xd)
